import logging

# import datetime
from typing import Annotated

from passlib.context import CryptContext

from storeapi.config import config
from jose import jwk, jwt, ExpiredSignatureError


from fastapi import HTTPException, Depends, status

from fastapi.security import OAuth2AuthorizationCodeBearer
import requests

logger = logging.getLogger(__name__)

KC_CLIENT_ID: str = config.KC_CLIENT_ID
KC_TOKEN_URL: str = config.KC_TOKEN_URL
KC_AUTH_URL: str = config.KC_AUTH_URL
KC_REFRESH_URL: str = config.KC_REFRESH_URL
KC_CERTS_URL: str = config.KC_CERTS_URL

oauth_2_scheme = OAuth2AuthorizationCodeBearer(
    tokenUrl=KC_TOKEN_URL,
    authorizationUrl=KC_AUTH_URL,
    refreshUrl=KC_REFRESH_URL,
)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def create_credentials_exception(detail: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=detail,
        headers={"WWW-Authenticate": "Bearer"},
    )


def has_role(role_name: str):
    async def check_role(token_data: Annotated[dict, Depends(valid_access_token)]):
        roles = token_data["resource_access"]["elbaapi"]["roles"]
        if role_name not in roles:
            raise HTTPException(status_code=403, detail="Unauthorized access")

    return check_role


async def valid_access_token(access_token: Annotated[str, Depends(oauth_2_scheme)]):
    url = KC_CERTS_URL
    optional_custom_headers = {"User-agent": "custom-user-agent"}

    try:
        # Fetch the JWKs
        response = requests.get(url, headers=optional_custom_headers)
        response.raise_for_status()
        jwks = response.json()

        signing_key = jwk.construct(jwks["keys"][0])

        data = jwt.decode(
            access_token,
            # signing_key.key,
            signing_key,
            algorithms=["RS256"],
            audience=KC_CLIENT_ID,
            options={"verify_exp": True},
        )
        print(data)
        return data
    except ExpiredSignatureError as ex:
        excep = create_credentials_exception("Token has expired")
        raise excep from ex
    except jwt.JWTError as ex:
        print(ex)
        excep = create_credentials_exception("Invalid token")
        raise excep from ex
