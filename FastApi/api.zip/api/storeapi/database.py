import databases
import sqlalchemy as SQLAlchemy
from storeapi.config import config

# metadata variable stores information about the database table and columns etc.
metadata = SQLAlchemy.MetaData()

campaign_table = SQLAlchemy.Table(
    "campaigns",
    metadata,
    SQLAlchemy.Column("id", SQLAlchemy.Integer, primary_key=True),
    SQLAlchemy.Column("name", SQLAlchemy.String(250)),
    SQLAlchemy.Column("template", SQLAlchemy.String(250)),
    SQLAlchemy.Column("isDraft", SQLAlchemy.Boolean, default=True),
    SQLAlchemy.Column("isPublished", SQLAlchemy.Boolean, default=False),
    SQLAlchemy.Column("isEnded", SQLAlchemy.Boolean, default=False),
)

# engine is used to connect to particular type of database like SQLite or Postgres
engine = SQLAlchemy.create_engine(
    # check_same_thread is set to False in case of connections to single threaded databases like SQLite for example
    config.DATABASE_URL,
    # connect_args={"check_same_thread": False},
)
metadata.create_all(engine)

# database variable is set to the Database object returned by using the databases module
print(config.DATABASE_URL)
print(config.DB_FORCE_ROLL_BACK)
database = databases.Database(
    url=config.DATABASE_URL, force_rollback=config.DB_FORCE_ROLL_BACK
)
